# Description

Please add an informative description that covers that changes made by the pull request and link all relevant issues.

# All TextIgniterJS Contribution checklist:

- [ ] **The pull request does not introduce [breaking changes].**
- [ ] **I have read the [contribution guidelines](../CONTRIBUTING.md).**
